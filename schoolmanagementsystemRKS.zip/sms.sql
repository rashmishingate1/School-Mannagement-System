-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2023 at 09:09 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `addteacher`
--

CREATE TABLE `addteacher` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `spec` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addteacher`
--

INSERT INTO `addteacher` (`id`, `name`, `spec`, `subject`) VALUES
(1, 'Monika', 'Computer Science', 'BDA'),
(2, 'Ganesh Dangat', 'Computer Science', 'Cloud computing'),
(3, 'Minal', 'Electronics', 'Circuit Design'),
(5, 'Patil S.A', 'Civil', 'Graphics');

-- --------------------------------------------------------

--
-- Table structure for table `feesubmit`
--

CREATE TABLE `feesubmit` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `monthname` varchar(255) NOT NULL,
  `annual` int(255) NOT NULL,
  `monthly` int(255) NOT NULL,
  `sport` int(255) NOT NULL,
  `library` int(255) NOT NULL,
  `Status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feesubmit`
--

INSERT INTO `feesubmit` (`id`, `name`, `monthname`, `annual`, `monthly`, `sport`, `library`, `Status`) VALUES
(56, 'Reeta', 'july', 92500, 9000, 500, 1000, 'unpaid'),
(78, 'Neha', 'july', 92500, 90000, 500, 1000, 'unpaid'),
(78, 'Neha', 'july', 92500, 90000, 500, 1000, 'unpaid'),
(78, 'Neha', 'july', 92500, 500, 500, 1000, 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `reportcard`
--

CREATE TABLE `reportcard` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `phy` int(255) NOT NULL,
  `chem` int(255) NOT NULL,
  `math` int(255) NOT NULL,
  `rollnumber` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reportcard`
--

INSERT INTO `reportcard` (`id`, `name`, `class`, `phy`, `chem`, `math`, `rollnumber`, `grade`) VALUES
(1, 'Rutu', 'btech', 66, 45, 98, '56', 'B'),
(1, 'Vijay', 'FY', 87, 89, 67, '56', 'A+'),
(99, 'Apeksha', 'btech', 78, 88, 98, '5', 'A+'),
(78, 'Sanika', 'btech', 56, 22, 67, '98', 'D');

-- --------------------------------------------------------

--
-- Table structure for table `stureg`
--

CREATE TABLE `stureg` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `phone` int(255) NOT NULL,
  `fatherphone` int(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `roll` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stureg`
--

INSERT INTO `stureg` (`id`, `name`, `surname`, `phone`, `fatherphone`, `class`, `roll`, `address`) VALUES
(1, 'Rashmi', 'Kishor', 928435433, 456783456, 'btech', '65', 'Satara'),
(34, 'Sonali', 'Satish', 897654345, 567890098, 'ty', '56', 'Satara'),
(89, 'Komal', 'Deepak', 897654345, 567890098, 'ty', '98', 'Satara'),
(57, 'Divya', 'Ramesh', 897654345, 567890098, 'sy', '98', 'Satara'),
(21, 'Ritesh', 'Rohan', 765698763, 349867587, 'sy', '87', 'Satara');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `id` int(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
